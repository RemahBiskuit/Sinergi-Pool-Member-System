<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  public function up(): void
  {
    Schema::table('admins', function (Blueprint $table) {
      $table->string('role')->default('admin')->after('password');
    });

    DB::table('admins')->where('username', 'admin')->update(['role' => 'superadmin']);
  }

  public function down(): void
  {
    Schema::table('admins', function (Blueprint $table) {
      $table->dropColumn('role');
    });
  }
};
